import { db } from './index.ts';
import { users, faturas, recibos, caixaMovs, auditoriaLogs, embarcacoes, agencias, armadores, atracacoes } from './schema.ts';
import { desc, eq } from 'drizzle-orm';
import { mockUtilizadores, mockFaturasIMP, mockRecibosIMP, mockCaixaMovs, mockAuditoriaLogs, mockEmbarcacoes, mockAgencias, mockArmadores, mockAtracacoes } from '../mock/data.ts';

// ---------------- USER QUERIES ----------------
export async function getUsers() {
  try {
    return await db.select().from(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function upsertUser(userData: any) {
  try {
    const existing = await db.select().from(users).where(eq(users.uid, userData.id || userData.uid)).limit(1);
    if (existing.length > 0) {
      const updated = await db.update(users).set({
        nome: userData.nome,
        email: userData.email,
        cargo: userData.cargo,
        funcao: userData.funcao,
        role: userData.role || userData.funcao,
        departamento: userData.departamento || 'Operações Marítimas',
        status: userData.status || 'Ativo',
        active: userData.active !== undefined ? userData.active : true,
        avatar: userData.avatar,
        fotoUrl: userData.fotoUrl || userData.avatar,
        telefone: userData.telefone,
        senha: userData.senha,
        ultimoAcesso: userData.ultimoAcesso || new Date().toISOString()
      }).where(eq(users.uid, userData.id || userData.uid)).returning();
      return updated[0];
    } else {
      const inserted = await db.insert(users).values({
        uid: userData.id || userData.uid || `USR-${Date.now()}`,
        nome: userData.nome,
        email: userData.email,
        cargo: userData.cargo,
        funcao: userData.funcao,
        role: userData.role || userData.funcao,
        departamento: userData.departamento || 'Operações Marítimas',
        status: userData.status || 'Ativo',
        active: userData.active !== undefined ? userData.active : true,
        avatar: userData.avatar,
        fotoUrl: userData.fotoUrl || userData.avatar,
        telefone: userData.telefone,
        senha: userData.senha || 'imp123',
        ultimoAcesso: userData.ultimoAcesso || new Date().toISOString()
      }).returning();
      return inserted[0];
    }
  } catch (error) {
    console.error('Error upserting user:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

// ---------------- FATURAS QUERIES ----------------
export async function getFaturas() {
  try {
    return await db.select().from(faturas).orderBy(desc(faturas.id));
  } catch (error) {
    console.error('Error fetching faturas:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertFatura(faturaData: any) {
  try {
    const inserted = await db.insert(faturas).values({
      faturaUid: faturaData.id || faturaData.nFatura,
      ano: faturaData.ano || 2026,
      seq: faturaData.seq || 1,
      nFatura: faturaData.nFatura,
      data: faturaData.data,
      cliente: faturaData.cliente,
      nif: faturaData.nif,
      navio: faturaData.navio,
      tipo: faturaData.tipo || 'Pesqueiro',
      grossTonnage: Number(faturaData.gross_tonnage || 0),
      itens: faturaData.itens || [],
      subtotal: Number(faturaData.subtotal || 0),
      iva: Number(faturaData.iva || 0),
      total: Number(faturaData.total || 0),
      saldoPago: Number(faturaData.saldo_pago || 0),
      saldoPendente: Number(faturaData.saldo_pendente || faturaData.total || 0),
      recibos: faturaData.recibos || [],
      estado: faturaData.estado || 'rascunho',
      criadoPor: faturaData.criado_por || 'Sistema IMP',
      justificativaAnulacao: faturaData.justificativaAnulacao || null,
      anuladoPor: faturaData.anulado_por || null,
      dataAnulacao: faturaData.data_anulacao || null
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting fatura:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

export async function updateFatura(faturaUid: string, updates: any) {
  try {
    const fieldsToUpdate: any = {};
    if (updates.estado !== undefined) fieldsToUpdate.estado = updates.estado;
    if (updates.saldo_pago !== undefined) fieldsToUpdate.saldoPago = updates.saldo_pago;
    if (updates.saldoPago !== undefined) fieldsToUpdate.saldoPago = updates.saldoPago;
    if (updates.saldo_pendente !== undefined) fieldsToUpdate.saldoPendente = updates.saldo_pendente;
    if (updates.saldoPendente !== undefined) fieldsToUpdate.saldoPendente = updates.saldoPendente;
    if (updates.recibos !== undefined) fieldsToUpdate.recibos = updates.recibos;
    if (updates.itens !== undefined) fieldsToUpdate.itens = updates.itens;
    if (updates.subtotal !== undefined) fieldsToUpdate.subtotal = updates.subtotal;
    if (updates.iva !== undefined) fieldsToUpdate.iva = updates.iva;
    if (updates.total !== undefined) fieldsToUpdate.total = updates.total;
    if (updates.justificativaAnulacao !== undefined) fieldsToUpdate.justificativaAnulacao = updates.justificativaAnulacao;
    if (updates.anulado_por !== undefined) fieldsToUpdate.anuladoPor = updates.anulado_por;
    if (updates.data_anulacao !== undefined) fieldsToUpdate.dataAnulacao = updates.data_anulacao;

    const updated = await db.update(faturas)
      .set(fieldsToUpdate)
      .where(eq(faturas.faturaUid, faturaUid))
      .returning();
    return updated[0];
  } catch (error) {
    console.error('Error updating fatura:', error);
    throw new Error('Database update failed', { cause: error });
  }
}

// ---------------- RECIBOS QUERIES ----------------
export async function getRecibos() {
  try {
    return await db.select().from(recibos).orderBy(desc(recibos.id));
  } catch (error) {
    console.error('Error fetching recibos:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertRecibo(reciboData: any) {
  try {
    const inserted = await db.insert(recibos).values({
      reciboUid: reciboData.id || reciboData.nRecibo,
      nRecibo: reciboData.nRecibo,
      faturaId: reciboData.fatura_id,
      nFatura: reciboData.nFatura,
      totalFatura: Number(reciboData.totalFatura || 0),
      valorAnteriorPago: Number(reciboData.valorAnteriorPago || 0),
      valor: Number(reciboData.valor || 0),
      saldoRestante: Number(reciboData.saldoRestante || 0),
      isLiquidacaoTotal: Boolean(reciboData.isLiquidacaoTotal),
      banco: reciboData.banco || 'CORIS BANK',
      talao: reciboData.talao || '',
      data: reciboData.data,
      hora: reciboData.hora,
      emissor: reciboData.emissor,
      cliente: reciboData.cliente,
      navio: reciboData.navio || '',
      observacoes: reciboData.observacoes || ''
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting recibo:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

// ---------------- CAIXA QUERIES ----------------
export async function getCaixaMovs() {
  try {
    return await db.select().from(caixaMovs).orderBy(desc(caixaMovs.id));
  } catch (error) {
    console.error('Error fetching caixa movements:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertCaixaMov(movData: any) {
  try {
    const inserted = await db.insert(caixaMovs).values({
      movUid: movData.id || `MOV-${Date.now()}`,
      data: movData.data,
      hora: movData.hora,
      descricao: movData.descricao,
      tipo: movData.tipo,
      valor: Number(movData.valor || 0),
      saldoApos: Number(movData.saldoApos || 0),
      criadoPor: movData.criado_por || 'Tesouraria',
      categoria: movData.categoria,
      talao: movData.talao || null,
      banco: movData.banco || null,
      documentoComprovativo: movData.documentoComprovativo || null,
      beneficiario: movData.beneficiario || null,
      autorizadoPor: movData.autorizado_por || null,
      justificativa: movData.justificativa || null,
      comprovativoAnexo: movData.comprovativoAnexo || null
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting caixa mov:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

// ---------------- AUDITORIA QUERIES ----------------
export async function getAuditoriaLogs() {
  try {
    return await db.select().from(auditoriaLogs).orderBy(desc(auditoriaLogs.id));
  } catch (error) {
    console.error('Error fetching auditoria logs:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertAuditoriaLog(logData: any) {
  try {
    const inserted = await db.insert(auditoriaLogs).values({
      logUid: logData.id || `AUD-${Date.now()}`,
      timestamp: logData.timestamp,
      userId: logData.user_id,
      userEmail: logData.user_email,
      acao: logData.acao,
      tabela: logData.tabela,
      itemId: logData.item_id,
      payloadJson: logData.payload_json,
      hashSha256: logData.hash_sha256,
      prevHash: logData.prev_hash
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting auditoria log:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

// ---------------- EMBARCAÇÕES, AGÊNCIAS, ARMADORES, ATRACAÇÕES ----------------
export async function getEmbarcacoes() {
  try {
    return await db.select().from(embarcacoes).orderBy(desc(embarcacoes.id));
  } catch (error) {
    console.error('Error fetching embarcacoes:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertEmbarcacao(embData: any) {
  try {
    const inserted = await db.insert(embarcacoes).values({
      embarcacaoUid: embData.id || `EMB-${Date.now()}`,
      nome: embData.nome,
      numeroImo: embData.numeroIMO || embData.numeroImo,
      indicativoChamada: embData.indicativoChamada,
      bandeira: embData.bandeira,
      portoRegisto: embData.portoRegisto,
      tipo: embData.tipo,
      tonelagemBruta: Number(embData.tonelagemBruta || 0),
      comprimentoForaFora: Number(embData.comprimentoForaFora || 0),
      caladoMaximo: Number(embData.caladoMaximo || 0),
      anoConstrucao: Number(embData.anoConstrucao || 2020),
      armadorId: embData.armadorId,
      armadorNome: embData.armadorNome,
      agenciaId: embData.agenciaId,
      agenciaNome: embData.agenciaNome,
      statusCertificacao: embData.statusCertificacao || 'Válida'
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting embarcacao:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

export async function getAgencias() {
  try {
    return await db.select().from(agencias).orderBy(desc(agencias.id));
  } catch (error) {
    console.error('Error fetching agencias:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertAgencia(agData: any) {
  try {
    const inserted = await db.insert(agencias).values({
      agenciaUid: agData.id || `AG-${Date.now()}`,
      nomeComercial: agData.nomeComercial,
      nif: agData.nif,
      licencaAtividade: agData.licencaAtividade,
      responsavelLegal: agData.responsavelLegal,
      telefone: agData.telefone,
      email: agData.email,
      endereco: agData.endereco,
      embarcacoesRepresentadas: Number(agData.embarcacoesRepresentadas || 0),
      status: agData.status || 'Ativa'
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting agencia:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

export async function getArmadores() {
  try {
    return await db.select().from(armadores).orderBy(desc(armadores.id));
  } catch (error) {
    console.error('Error fetching armadores:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertArmador(armData: any) {
  try {
    const inserted = await db.insert(armadores).values({
      armadorUid: armData.id || `ARM-${Date.now()}`,
      nomeRazaoSocial: armData.nomeRazaoSocial,
      paisOrigem: armData.paisOrigem,
      tipoEntidade: armData.tipoEntidade || 'Nacional',
      contactoOficial: armData.contactoOficial,
      email: armData.email,
      frotaContada: Number(armData.frotaContada || 0)
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting armador:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

export async function getAtracacoes() {
  try {
    return await db.select().from(atracacoes).orderBy(desc(atracacoes.id));
  } catch (error) {
    console.error('Error fetching atracacoes:', error);
    throw new Error('Database query failed', { cause: error });
  }
}

export async function insertAtracacao(atracData: any) {
  try {
    const inserted = await db.insert(atracacoes).values({
      atracacaoUid: atracData.id || `ATR-${Date.now()}`,
      codigoEscala: atracData.codigoEscala,
      embarcacaoId: atracData.embarcacaoId,
      embarcacaoNome: atracData.embarcacaoNome,
      agenciaNome: atracData.agenciaNome,
      portoNome: atracData.portoNome,
      caisDesignado: atracData.caisDesignado,
      dataChegadaPrevista: atracData.dataChegadaPrevista,
      dataAtracacaoEfetiva: atracData.dataAtracacaoEfetiva || null,
      dataSaidaPrevista: atracData.dataSaidaPrevista,
      status: atracData.status || 'Anunciada',
      servicosSolicitados: atracData.servicosSolicitados || [],
      manifestoCarga: atracData.manifestoCarga || {}
    }).returning();
    return inserted[0];
  } catch (error) {
    console.error('Error inserting atracacao:', error);
    throw new Error('Database mutation failed', { cause: error });
  }
}

// ---------------- SEED DATABASE IF EMPTY ----------------
export async function seedDatabaseIfEmpty() {
  try {
    const currentUsers = await db.select().from(users).limit(1);
    if (currentUsers.length === 0) {
      console.log('Seeding initial IMP users to PostgreSQL...');
      for (const u of mockUtilizadores) {
        await upsertUser(u);
      }
    }

    const currentFaturas = await db.select().from(faturas).limit(1);
    if (currentFaturas.length === 0) {
      console.log('Seeding initial IMP faturas to PostgreSQL...');
      for (const f of mockFaturasIMP) {
        await insertFatura(f);
      }
    }

    const currentRecibos = await db.select().from(recibos).limit(1);
    if (currentRecibos.length === 0) {
      for (const r of mockRecibosIMP) {
        await insertRecibo(r);
      }
    }

    const currentCaixa = await db.select().from(caixaMovs).limit(1);
    if (currentCaixa.length === 0) {
      for (const m of mockCaixaMovs) {
        await insertCaixaMov(m);
      }
    }

    const currentLogs = await db.select().from(auditoriaLogs).limit(1);
    if (currentLogs.length === 0) {
      for (const l of mockAuditoriaLogs) {
        await insertAuditoriaLog(l);
      }
    }

    const currentEmbarcacoes = await db.select().from(embarcacoes).limit(1);
    if (currentEmbarcacoes.length === 0) {
      for (const e of mockEmbarcacoes) {
        await insertEmbarcacao(e);
      }
    }

    const currentAgencias = await db.select().from(agencias).limit(1);
    if (currentAgencias.length === 0) {
      for (const a of mockAgencias) {
        await insertAgencia(a);
      }
    }

    const currentArmadores = await db.select().from(armadores).limit(1);
    if (currentArmadores.length === 0) {
      for (const arm of mockArmadores) {
        await insertArmador(arm);
      }
    }

    const currentAtracacoes = await db.select().from(atracacoes).limit(1);
    if (currentAtracacoes.length === 0) {
      for (const atr of mockAtracacoes) {
        await insertAtracacao(atr);
      }
    }

    console.log('Database seeding complete.');
    return { success: true };
  } catch (error) {
    console.error('Error seeding database:', error);
    return { success: false, error };
  }
}
