import { FaturaIMP, ReciboIMP, CaixaMov, AuditoriaLog, Embarcacao, AgenciaMaritima, Armador, Atracacao, Utilizador } from '../types';

const SESSION_LOGGED_IN_KEY = 'imp_session_logged_in';
const SESSION_USER_ID_KEY = 'imp_session_user_id';
const SESSION_ACTIVE_MODULE_KEY = 'imp_session_active_module';

export const sessionManager = {
  saveSession(user: Utilizador, activeModule?: string) {
    try {
      localStorage.setItem(SESSION_LOGGED_IN_KEY, 'true');
      localStorage.setItem(SESSION_USER_ID_KEY, user.id);
      if (activeModule) {
        localStorage.setItem(SESSION_ACTIVE_MODULE_KEY, activeModule);
      }
    } catch (e) {
      console.warn('Could not save session to localStorage', e);
    }
  },

  updateActiveModule(moduleKey: string) {
    try {
      localStorage.setItem(SESSION_ACTIVE_MODULE_KEY, moduleKey);
    } catch (e) {
      console.warn('Could not update active module in localStorage', e);
    }
  },

  getSession(): { isLoggedIn: boolean; userId: string | null; activeModule: string | null } {
    try {
      const isLoggedIn = localStorage.getItem(SESSION_LOGGED_IN_KEY) === 'true';
      const userId = localStorage.getItem(SESSION_USER_ID_KEY);
      const activeModule = localStorage.getItem(SESSION_ACTIVE_MODULE_KEY);
      return { isLoggedIn, userId, activeModule };
    } catch (e) {
      return { isLoggedIn: false, userId: null, activeModule: null };
    }
  },

  clearSession() {
    try {
      localStorage.removeItem(SESSION_LOGGED_IN_KEY);
      localStorage.removeItem(SESSION_USER_ID_KEY);
      localStorage.removeItem(SESSION_ACTIVE_MODULE_KEY);
    } catch (e) {
      console.warn('Could not clear session', e);
    }
  }
};

// API calls with automatic backend synchronization
export async function apiFetchFaturas(): Promise<FaturaIMP[] | null> {
  try {
    const res = await fetch('/api/faturas');
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Using client cache for faturas:', e);
  }
  return null;
}

export async function apiSaveFatura(fatura: FaturaIMP): Promise<void> {
  try {
    await fetch('/api/faturas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fatura),
    });
  } catch (e) {
    console.warn('Failed to sync fatura to PostgreSQL:', e);
  }
}

export async function apiUpdateFatura(faturaUid: string, updates: Partial<FaturaIMP>): Promise<void> {
  try {
    await fetch(`/api/faturas/${encodeURIComponent(faturaUid)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
  } catch (e) {
    console.warn('Failed to update fatura in PostgreSQL:', e);
  }
}

export async function apiFetchRecibos(): Promise<ReciboIMP[] | null> {
  try {
    const res = await fetch('/api/recibos');
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('Using client cache for recibos:', e);
  }
  return null;
}

export async function apiSaveRecibo(recibo: ReciboIMP): Promise<void> {
  try {
    await fetch('/api/recibos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(recibo),
    });
  } catch (e) {
    console.warn('Failed to sync recibo to PostgreSQL:', e);
  }
}

export async function apiFetchCaixa(): Promise<CaixaMov[] | null> {
  try {
    const res = await fetch('/api/caixa');
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('Using client cache for caixa:', e);
  }
  return null;
}

export async function apiSaveCaixaMov(mov: CaixaMov): Promise<void> {
  try {
    await fetch('/api/caixa', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(mov),
    });
  } catch (e) {
    console.warn('Failed to sync caixa mov to PostgreSQL:', e);
  }
}

export async function apiFetchAuditoria(): Promise<AuditoriaLog[] | null> {
  try {
    const res = await fetch('/api/auditoria');
    if (res.ok) return await res.json();
  } catch (e) {
    console.warn('Using client cache for auditoria:', e);
  }
  return null;
}

export async function apiSaveAuditoriaLog(log: AuditoriaLog): Promise<void> {
  try {
    await fetch('/api/auditoria', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(log),
    });
  } catch (e) {
    console.warn('Failed to sync audit log to PostgreSQL:', e);
  }
}
